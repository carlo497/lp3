var left = document.getElementById("divRight");
var block = document.createElement('div');
block.setAttribute('class', 'boxTop yourChoice');

//header
var header=document.createElement('a');
header.setAttribute('class', 'title');
header.appendChild(document.createTextNode('Twój wybór:'));

//content
var mytext=document.createTextNode('');

block.appendChild(header);
block.appendChild(mytext);
block.appendChild(document.createElement('ol'));
var blockPosition = block.offsetTop;
left.appendChild(block);

var checkbox = document.getElementsByClassName("chk");
for(var i = 0, j=checkbox.length; i<j; i++){
	checkbox[i].addEventListener("click", function() {
		var id = this.getAttribute('id').split('_').pop();
		if(this.checked == true) {
			check(id);
		} else {
			uncheck(id,true);
		}
	  //alert(this.getAttribute('id').split('_').pop());
	}, false);
	if(checkbox[i].checked) {
		var id = checkbox[i].getAttribute('id').split('_').pop();
		check(id);
	}
}
window.addEventListener('scroll',function() {
	if(blockPosition == 0) blockPosition = block.offsetTop;
	if(window.pageYOffset > blockPosition) {
		if (!block.className.match(new RegExp('(\\s|^)sticky(\\s|$)'))) block.className += " sticky";
	} else {
		var reg = new RegExp('(\\s|^)sticky(\\s|$)');
		block.className=block.className.replace(reg,' ');
	}
}, false);
function check(id) {
	var box = document.createElement('li');
	var string = document.createTextNode(document.getElementById('utwor_'+id).parentElement.parentElement.getElementsByTagName('td')[1].textContent);
	var link = document.createElement('a');
	
	link.onclick = function() { uncheck(id,false); };
	link.appendChild(document.createTextNode('(usuń)'));
	box.setAttribute('id',id);
	box.appendChild(string);
	box.appendChild(link);
	block.getElementsByTagName('ol')[0].appendChild(box);
}
function uncheck(id,box) {
	var child = document.getElementById(id);
	block.getElementsByTagName('ol')[0].removeChild(child);
	//document.getElementById('utwor_'+id).checked = false;
	if(!box) document.getElementById('utwor_'+id).click();
}